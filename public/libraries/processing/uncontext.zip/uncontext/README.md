## How To Install

1. Make a new folder named `uncontext` in your processing `libraries` folder.
2. Copy the contents of this github directory into the new `uncontext` folder you made.
3. Restart processing, the library should now appear in the `Add Library` list.
4. Check out the examples or documentation to get started.